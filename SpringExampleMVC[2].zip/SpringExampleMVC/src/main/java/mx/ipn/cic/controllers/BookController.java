package mx.ipn.cic.controllers;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import mx.ipn.cic.model.Book;
import mx.ipn.cic.services.BookService;;

@Controller
@RequestMapping(value = "/book")
public class BookController {
	
	@Autowired
	private BookService bookService;

	/* Método de formularios */
	
	@RequestMapping(value = "/newForm", method = RequestMethod.GET)
	public String getNewForm() {
		return "book/new_book";
	}

	@RequestMapping(value = "/{id}/updateForm", method = RequestMethod.GET)
	public String getupdateForm(@PathVariable Integer id, Model model) {
		Book book = this.bookService.findById(id);
		model.addAttribute("book", book);
		return "book/update_form_book";
	}

	/* Métodos CRUD */

	@RequestMapping(method = RequestMethod.GET)
	public String getAll(Model model) {
		List<Book> booksList = this.bookService.getAll();
		model.addAttribute("books", booksList);
		return "book/allbooks";
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public String getById(@PathVariable Integer id, Model model) {
		Book book = this.bookService.findById(id);
		model.addAttribute("book", book);
		return "book/single_book";
	}

	@RequestMapping(method = RequestMethod.POST)
	public String newRegister(Book newBook) {
		this.bookService.create(newBook);
		return "book/ok";
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.POST)
	public String update(@PathVariable Integer id,String title, String author, String edition, Integer available) {
		Book book = this.bookService.findById(id);
		if (book != null) {
			book.setAuthor(author);;
			book.setAvailable(available);
			book.setEdition(edition);
			book.setTitle(title);
			this.bookService.update(book);
		}
		return "book/ok";
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable Integer id) throws HibernateException, SQLException {
		this.bookService.delete(id);
		return "book/ok";
	}	
}
