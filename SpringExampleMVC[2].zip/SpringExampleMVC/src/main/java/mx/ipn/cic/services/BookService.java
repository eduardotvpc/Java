package mx.ipn.cic.services;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.ipn.cic.model.Book;
import mx.ipn.cic.repositories.BookRepository;;

@Service
public class BookService {
	@Autowired
	private BookRepository bookRepository;
	public List<Book> getAll(){
		List<Book> books = this.bookRepository.fetchAll();
		return books;
	}
	
	public Book findById(Integer id) {
		Book book = this.bookRepository.fetchById(id);
		return book;
	}

	public Book create(Book book) {
		book = this.bookRepository.save(book);
		return book;
	}

	public Book update(Book book) {
		book = this.bookRepository.update(book);
		return book;
	}
	
	public boolean delete(Integer id) throws HibernateException, SQLException {
		Book book = this.findById(id);
		boolean success = this.bookRepository.delete(book);
		return success;
	}
}
