package mx.ipn.cic.repositories;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import mx.ipn.cic.model.Rol;

@Repository
public class RolRepository {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	public List<Rol> fetchAll() {
		Session session = null;
		List<Rol> roles = null;
		try {
			session = this.sessionFactory.openSession();
			roles = session.createCriteria(Rol.class).list();
		} catch (HibernateException e) {
		} finally {
			session.close();
		}
		return roles;
	}
	
	/**
	 * Método para obtener un rol por su identificador
	 * 
	 * @param id Identificador del rol a buscar
	 * @return El rol encontrado o "null" si no existe
	 */
	public Rol fetchById(Integer id) {
		Session session = null;
		Rol rol = null;
		try {
			session = this.sessionFactory.openSession();
			rol = (Rol) session.get(Rol.class, id);
		} catch (HibernateException e) {
			System.out.println(e.getStackTrace());
		} finally {
			session.close();
		}
		return rol;
	}
	
	/**
	 * 
	 * @param rol
	 * @return
	 */
	public Rol save(Rol rol) {
		Session session = null;
		try {
			session = this.sessionFactory.openSession();
			session.save(rol);
		} catch (HibernateException e) {
			rol = null;
		} finally {
			session.close();
		}
		return rol;
	}

	/**
	 * 
	 * @param rol
	 * @return
	 */
	/*public Rol update(Rol rol) {
		Session session = null;
		try {
			session = this.sessionFactory.openSession();
			session.update(rol);
		} catch (HibernateException e) {
			rol = null;
		} finally {
			session.close();
		}
		return rol;
	}*/
	public Rol update(Rol rol) {
		Session session = null;
		try {
			session = this.sessionFactory.openSession();
			Object o = session.load(Rol.class,rol.getId());
			Rol p=(Rol)o;
			Transaction tx = session.beginTransaction();
			session.merge(rol);
			session.update(p);
			tx.commit();
			System.out.println("Rol Modificado.....!!");
		} catch (HibernateException e) {
			rol = null;
		} finally {
			session.close();
		}
		return rol;
	}

	/**
	 * 
	 * @param rol
	 * @return
	 */
	/*public boolean delete(Rol rol) throws HibernateException, SQLException {
		Session session = null;
		boolean success;
		try {
			session = this.sessionFactory.openSession();
			System.out.println("Antes Delet: " + rol.toString());
			session.delete(rol);
			System.out.println("Despues Delet: " + rol.toString());
			success = true;
		} catch (HibernateException e) {
			success = false;
			System.err.println("Error al Eliminar");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return success;
	}*/
	
	public boolean delete(Rol rol) throws HibernateException, SQLException {
		Session session = null;
		session = this.sessionFactory.openSession();
		Object o = session.load(Rol.class,rol.getId());
		Rol p=(Rol)o;
		Transaction tx = session.beginTransaction();
		session.delete(p);
		System.out.println("Rol borrado.....!!");
		tx.commit();
		session.close();
		return true;
	}

}
