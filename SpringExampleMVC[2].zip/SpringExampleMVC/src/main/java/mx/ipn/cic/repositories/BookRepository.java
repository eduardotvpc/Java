package mx.ipn.cic.repositories;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import mx.ipn.cic.model.Book;

@Repository
public class BookRepository {
	@Autowired
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	public List<Book> fetchAll() {
		Session session = null;
		List<Book> books = null;
		try {
			session = this.sessionFactory.openSession();
			books = session.createCriteria(Book.class).list();
		} catch (HibernateException e) {
		} finally {
			session.close();
		}
		return books;
	}
	
	public Book fetchById(Integer id) {
		Session session = null;
		Book book = null;
		try {
			session = this.sessionFactory.openSession();
			book = (Book) session.get(Book.class, id);
		} catch (HibernateException e) {
			System.out.println(e.getStackTrace());
		} finally {
			session.close();
		}
		return book;
	}
	
	public Book save(Book book) {
		Session session = null;
		try {
			session = this.sessionFactory.openSession();
			session.save(book);
		} catch (HibernateException e) {
			book = null;
		} finally {
			session.close();
		}
		return book;
	}

	public Book update(Book book) {
		Session session = null;
		try {
			session = this.sessionFactory.openSession();
			Object o = session.load(Book.class,book.getId());
			Book p=(Book)o;
			Transaction tx = session.beginTransaction();
			session.merge(book);
			session.update(p);
			tx.commit();
			System.out.println("Libro Modificado.....!!");
		} catch (HibernateException e) {
			book = null;
		} finally {
			session.close();
		}
		return book;
	}
	
	/*public boolean delete(Book book) {
		Session session = null;
		boolean success;
		try {
			session = this.sessionFactory.openSession();
			session.delete(book);
			success = true;
		} catch (HibernateException e) {
			success = false;
		} finally {
			session.close();
		}
		return success;
	}*/
	
	public boolean delete(Book book) throws HibernateException, SQLException {
		Session session = null;
		session = this.sessionFactory.openSession();
		Object o = session.load(Book.class,book.getId());
		Book p=(Book)o;
		Transaction tx = session.beginTransaction();
		session.delete(p);
		System.out.println("Libro borrado.....!!");
		tx.commit();
		session.close();
		return true;
	}
}
