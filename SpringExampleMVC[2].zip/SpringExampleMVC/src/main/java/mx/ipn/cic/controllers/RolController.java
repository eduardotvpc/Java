package mx.ipn.cic.controllers;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import mx.ipn.cic.model.Rol;
import mx.ipn.cic.services.RolService;

@Controller
@RequestMapping(value = "/rol")
public class RolController {
	
	@Autowired
	private RolService rolService;

	/* Método de formularios */
	
	@RequestMapping(value = "/newForm", method = RequestMethod.GET)
	public String getNewForm() {
		return "rol/new_rol";
	}

	@RequestMapping(value = "/{id}/updateForm", method = RequestMethod.GET)
	public String getupdateForm(@PathVariable Integer id, Model model) {
		Rol rol = this.rolService.findById(id);
		model.addAttribute("rol", rol);
		return "rol/update_form_rol";
	}

	/* Métodos CRUD */

	@RequestMapping(method = RequestMethod.GET)
	public String getAll(Model model) {
		List<Rol> rolesList = this.rolService.getAll();
		model.addAttribute("roles", rolesList);
		return "rol/allrols";
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public String getById(@PathVariable Integer id, Model model) {
		Rol rol = this.rolService.findById(id);
		model.addAttribute("rol", rol);
		return "rol/single_rol";
	}

	@RequestMapping(method = RequestMethod.POST)
	public String newRegister(Rol newRol) {
		this.rolService.create(newRol);
		return "rol/ok";
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.POST)
	public String update(@PathVariable Integer id, String name, String description) {
		Rol rol = this.rolService.findById(id);
		if (rol != null) {
			rol.setName(name);
			rol.setDescription(description);
			this.rolService.update(rol);
		}
		return "rol/ok";
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable Integer id) throws HibernateException, SQLException {
		this.rolService.delete(id);
		return "rol/ok";
	}	
	
}
