package mx.ipn.cic.services;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.ipn.cic.model.Rol;
import mx.ipn.cic.repositories.RolRepository;

@Service
public class RolService {
	
	@Autowired
	private RolRepository rolRepository;
	public List<Rol> getAll(){
		List<Rol> roles = this.rolRepository.fetchAll();
		return roles;
	}
	
	public Rol findById(Integer id) {
		Rol rol = this.rolRepository.fetchById(id);
		return rol;
	}

	public Rol create(Rol rol) {
		rol = this.rolRepository.save(rol);
		return rol;
	}

	public Rol update(Rol rol) {
		rol = this.rolRepository.update(rol);
		return rol;
	}
	
	public boolean delete(Integer id) throws HibernateException, SQLException {
		Rol rol = this.findById(id);
		boolean success = this.rolRepository.delete(rol);
		return success;
	}

}
